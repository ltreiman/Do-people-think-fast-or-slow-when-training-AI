// Need to delete when editing instructions
repeated_times = 2

  function createInstrPage(text){
    return ["<div align=center><div class = 'center_text'; style = 'width: 65vw';>" + text + "<br></div>"]
  }



  function instructions1(){ 
    human = '<body style="background-color:black;"><div style="height: 200px; width: 200px; margin:0 auto;background-color:'+train_and_color['human']+';"><img src="'+opponents_images['human'][0]+'" ></div></body>'
    ai = '<body style="background-color:black;"><div style="height: 200px; width: 200px; margin:0 auto;background-color:'+train_and_color['AI']+';"><img src="'+opponents_images['AI'][0]+'" ></div></body>'
    instructions = [
      "Welcome to the experiment!<br><br> Please read the instructions carefully in order to understand the task.<br><br>Press <b>next</b> or <b>spacebar</b> to continue.<br><br>",
      "For this experiment, you will play with partners.<br><br>For each trial, you will play with one partner that could be either another human participant recruited on Prolific or artificial intelligence (AI). <br><br> The AI is a computer program that has been trained to make choices by observing other human participants do the same task that you are going to complete.<br><br>",
      "On each trial, you and your partner will decide how to split $"+split_amount+" amongst yourselves. <br><br> Your partner has already decided how to divide the  $"+split_amount+"  and you can choose whether to <u><b>accept</b></u> or <u><b>reject</b></u> this proposal.<br><br>",
      "In other words, your partner is the <b><u>proposer</u></b> since they are proposing offer.<br><br>Similarly, you are the <b><u>responder</u></b> since you are responding to their offers.<br><br>",
      "If you <u><b>accept</b></u> the offer, then you and your partner will receive the amount your partner proposed.<br><br>For example, if your partner proposed to give you $7 and keep $3 for themself, then by accepting this offer you would earn $7 and they would earn $3.<br><br>",
      "If you <u><b>reject</b></u> the offer, then you and your partner will both receive nothing.<br><br>For example, if your partner proposed to give you $7 and keep $3 for themself, then by rejecting this offer you would both earn $0.<br><br>",
      "On each trial, you will see a screen displaying whether your partner is another human participant or the AI.<br><br> This screen will appear for "+times.opponent/1000+" seconds. <br><br>",
      "If your partner is another human participant, you will see this icon on the screen."+human+"<br><br>",
      "If your partner is the AI, you will see this icon on the screen."+ai+"<br><br>",
      "You will then see your partner's offer and will choose whether to <b>accept</b> or <b>reject</b> this offer.<br><br>To <b>accept</b> the offer, press the <b>F Key</b>.<br><br>To <b>reject</b> the offer, press the <b>J Key</b>.<br><br>",
      "You will now complete "+npractice+" practice trials. <br><br>Since this just a practice trial, there will be no icon displayed.<br><br>You will not receive any money from these trials. <br><br>Press <b>next</b> or <b>spacebar</b> to continue.<br><br>",
    ]

    
    return instructions.map(x => createInstrPage(x))}

  function instructions2(){ 
    training_for = ""
    ai_sentence = ""
    ai_sentence_recap = ""
    ai_sentence_screen = ""
    recap_number = 3
    word = "a"
    if(condition_assignment.includes("training")){ 
      recap_number = 4
      ai_sentence_screen = condition_assignment.includes("self") ? "<b>you will play with the AI that you help train here.</b><br><br><b>This means that you will encounter the AI you train in the follow-up experiment!<b><br><br>": "<b>you will <u>not</u> encounter the AI you train.<br><br>Instead, the AI you help train will only play against other Prolific participants.</b><br><br>"
      ai_sentence = condition_assignment.includes("self") ? "<b>In this follow-up experiment, you will play with the AI that is trained using your responses in this experiment.</b><br><br>": "<b>The AI you train will play against other Prolific participants.<br><br>You will not encounter the AI you train in the follow-up experiment.</b><br><br>"
      training_for = condition_assignment.includes("self") ? "you will encounter in a follow-up experiment." : "will play with other Prolific users in future experiments."
      ai_sentence_recap = "3. Your responses will be used to train an AI Responder that "+training_for+"<br><br>"

    }
    if(condition_assignment.includes("self")){
      word = "this"
    }


    ai_instructions =  [
      "Before you start the experiment, we need to explain one more aspect. <br><br>",
      "Your responses will be used to train an AI to <u>respond</u> to offers, just like you are doing here.<br><br>This AI will learn by observing your responses.<br><br>The AI will learn by mimicking how you respond to offers.<br><br>",
      "To remind you that an AI is observing your choices, you will see a screen with the following text before each offer:  <h2><b><u>"+ai_texts[condition_assignment]+"</u></b></h2><br><br>",
      "After you complete this experiment, you will be invited to participate in a follow-up experiment.<br><br>In this follow-up experiment, "+ai_sentence_screen+"",
    ]
    normal_instructions = [
      "After you make all your offers, "+noutcomes+" offer will be randomly selected and resolved. <br><br>You will earn a bonus of "+bonus_percentage*100+"% of what you received from that offer.<br><br>",
      "Within the next few weeks, <u><b>you will be invited back to play as the proposer.</b></u><br><br>This means that you will make the proposals in the follow-up experiment.<br><br>In other words, you are switching roles from what you are doing here.<br><br>We will recruit participants to respond to your proposals you make in the follow-up experiment.<br><br>",
      "For coming back to participate in the follow-up experiment, you will earn a <u>bonus that is "+bonus_increase+"X</u> as much money than this experiment.<br><br><b>"+ai_sentence+"</b>",
      "To recap:<br><br>1. You are going to choose between accepting and rejecting offers.<br><br>2. Sometimes, human participants made these offers, other times an AI made them.<br><br>"+ai_sentence_recap+""+recap_number+". Within the next few weeks, you will be invited to participate in "+word+" follow-up experiment where you will switch roles and play as the proposer.<br><br>",
      "Before you complete the experiment, you will be asked a few questions about the rules of the experiment.<br><br>You must get all questions right before you can proceed.<br><br><b>If you give the wrong answer to any question, then you will be required to read the instructions again.</b><br><br>"
    ]

    instructions = condition_assignment.includes("training") ? ai_instructions.concat(normal_instructions): normal_instructions
    return instructions.map(x => createInstrPage(x))}

    function instructions3(){
      return ["You are now ready for the experiment. You will complete "+total_trials+" trials. <br><br>Press space or click the next button to begin! <br><br>"].map(x => createInstrPage(x))}

  






  
