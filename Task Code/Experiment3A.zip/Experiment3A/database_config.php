<?php
$servername = "localhost";
$port = 3306;
$username = '';
$password = '';
$dbname = '';
?>
