// Define count object in array
Object.defineProperties(Array.prototype, {
    count: {
        value: function(value) {
            return this.filter(x => x==value).length;
        }
    }
});

// Functions used
const arrayRange = (start, stop, step) =>
    Array.from(
    { length: (stop - start) / step + 1 },
    (value, index) => start + index * step
    );



function weightedRandom(prob) {
    let i, sum=0, r=Math.random();
    for (i in prob) {
      sum += prob[i];
      if (r <= sum) return i;
    }
}

Object.defineProperty(Array.prototype, 'chunk', {
    value: function(chunkSize) {
      var R = [];
      for (var i = 0; i < this.length; i += chunkSize)
        R.push(this.slice(i, i + chunkSize));
      return R;
    }
  });

function random_trials(total_trials, noutcomes){
    start = 1
    end = total_trials
    temp = [...Array(end - start + 1).keys()].map(x => x + start);
    randomTrials = jsPsych.randomization.sampleWithoutReplacement(temp, noutcomes);
    return randomTrials
}

// Function to repeat: takes an array arr and repeats to the size of len (so want to use total_trials for the number of length)
function repeat(arr, len) {
    while (arr.length < len) arr = arr.concat(arr.slice(0, len-arr.length));
    return arr;
}


// Randomly shuffle the array
function shuffleArray(array, l) {
    for (var i = l - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array
}

function shuffle(arr1, arr2){
    "use strict";
    var l = arr1.length,
    i = 0,
    rnd,
    tmp1,
    tmp2;

    while (i < l) {
        rnd = Math.round(Math.random() * i)
        tmp1 = arr1[i]
        tmp2 = arr2[i]
        arr1[i] = arr1[rnd]
        arr2[i] = arr2[rnd]
        arr1[rnd] = tmp1
        arr2[rnd] = tmp2
        i += 1
    }
    return {array1: arr1, array2: arr2}
}

function cartesian(...args) {
    var r = [], max = args.length-1;
    function helper(arr, i) {
        for (var j=0, l=args[i].length; j<l; j++) {
            var a = arr.slice(0); // clone arr
            a.push(args[i][j]);
            if (i==max)
                r.push(a);
            else
                helper(a, i+1);
        }
    }
    helper([], 0);
    return r;
}

